#include <iostream>
#include <boost/asio.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/lexical_cast.hpp>

using namespace std;

using boost::asio::ip::tcp;
using boost::property_tree::ptree;

namespace Client {
    boost::asio::io_service io_service;
    tcp::socket socket(io_service);
    boost::system::error_code ignored_error;

    ptree root;
    ptree messages_;
    std::vector<ptree> message;

    void connect() {
        tcp::resolver resolver(io_service);
        tcp::resolver::query query("localhost", "5555");
        tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);

        boost::asio::connect(socket, endpoint_iterator, ignored_error);
        std::cout << ignored_error.message() << std::endl;
    }

    void addMessage(ptree m) {
        message.push_back(m);
    }

    void messageSend() {
        std::stringstream ss;

        for(auto node : message){
            messages_.push_back(std::make_pair("", node));
        }
        root.add_child("messages", messages_);

        write_json(ss, root);
        std::string jsonString = ss.str();
        boost::asio::write(socket, boost::asio::buffer(jsonString), ignored_error);
        std::cout << "Email kérések kiküldve." << std::endl;

    }

    void signalHandler(int signal) {
        if(!message.empty()) {
            Client::messageSend();
        }

        socket.close();
        exit(signal);
    }
}


int main() {
    signal(SIGINT, Client::signalHandler);
    Client::connect();


    for(;;){
        std::string from,to,data;

        std::cout << "Ctrl+c ha nem akarsz több emailt írni.\nFrom: " << std::endl;
        getline(cin, from);
        std::cout << "To: " << std::endl;
        getline(cin, to);
        std::cout << "Data: " << std::endl;
        getline(cin, data);

        ptree temp;
        temp.put("From",from);
        temp.put("To",to);
        temp.put("Data", data);
        if(!(from.empty() || to.empty() || data.empty())) {
            Client::addMessage(temp);
        }
    }
}