//
// Created by aximcore on 2015.08.23..
//

#include "requestsHandling.h"
#include "manager.h"

tcp_connection::pointer tcp_connection::create(boost::asio::io_service& io_service) {
    return tcp_connection::pointer(new tcp_connection(io_service));
}

tcp::socket& tcp_connection::socket() {
    return tcp_connection::socket_;
}

void tcp_connection::start() {
    boost::asio::async_read(tcp_connection::socket_, tcp_connection::message_,
                            boost::bind(&tcp_connection::handleRead, shared_from_this(),
                                        boost::asio::placeholders::error,
                                        boost::asio::placeholders::bytes_transferred));
}

tcp_connection::tcp_connection(boost::asio::io_service& io_service)
        : socket_(io_service) {}

void tcp_connection::handleRead(const boost::system::error_code& error, size_t bytes_transferred) {
    if (error && error != boost::asio::error::eof) {
        std::cerr << "Hiba: " << error.message() << std::endl;
        return;
    }

    if(!message_.size()){
        return;
    }

    Manager::saveRequest(&message_);

}

tcp_server::tcp_server(boost::asio::io_service& io_service)
        : acceptor_(io_service, tcp::endpoint(tcp::v4(), 5555)) {
    start_accept();
}

void tcp_server::start_accept() {
    tcp_connection::pointer new_connection =
            tcp_connection::create(acceptor_.get_io_service());

    tcp_server::acceptor_.async_accept(new_connection->socket(),
                                       boost::bind(&tcp_server::handle_accept, this, new_connection,
                                                   boost::asio::placeholders::error));
}

void tcp_server::handle_accept(tcp_connection::pointer new_connection,
                               const boost::system::error_code& error) {
    if (!error)
    {
        new_connection->start();
    }

    tcp_server::start_accept();
}
