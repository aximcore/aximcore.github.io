//
// Created by aximcore (aximcore@gmail.com)
//

#include "manager.h"
#include "requestsHandling.h"

int main() {
    signal(SIGINT, Manager::signalHandler);
    Manager* m = Manager::getInstance();

    try
    {
        boost::asio::io_service io_service;
        tcp_server server(io_service);
        io_service.run();
    }
    catch (std::exception& e)
    {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}