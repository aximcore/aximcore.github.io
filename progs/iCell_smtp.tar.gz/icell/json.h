//
// Created by aximcore on 2015.08.21..
//

#ifndef ICELL_JSON_H
#define ICELL_JSON_H

#include "smtp.h"

#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>

using boost::property_tree::ptree;

class JSON {
    std::string fileName;
    std::fstream file;

    ptree root;
    ptree messages_;
    std::vector<ptree> message;
public:
    JSON();
    void saveFile(std::queue<Message>);
    std::queue<Message> loadFile();
    static std::queue<Message> parseRequest(boost::asio::streambuf*);
};

#endif //ICELL_JSON_H


