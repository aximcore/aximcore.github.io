//
// Created by aximcore on 2015.08.23..
//

#ifndef ICELL_REQUESTSHANDLING_H
#define ICELL_REQUESTSHANDLING_H

#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/asio.hpp>
#include <boost/foreach.hpp>
#include <iostream>
#include <string>

using boost::asio::ip::tcp;

class tcp_connection : public boost::enable_shared_from_this<tcp_connection> {

    tcp_connection(boost::asio::io_service& io_service);
    void handleRead(const boost::system::error_code& error,
                    size_t bytes_transferred);

    tcp::socket socket_;
    boost::asio::streambuf message_;
public:
    typedef boost::shared_ptr<tcp_connection> pointer;

    static pointer create(boost::asio::io_service& io_service);
    tcp::socket& socket();
    void start();
};

class tcp_server {
    void start_accept();
    void handle_accept(tcp_connection::pointer new_connection,
                       const boost::system::error_code& error);

    tcp::acceptor acceptor_;

public:
    tcp_server(boost::asio::io_service& io_service);
};

#endif //ICELL_REQUESTSHANDLING_H
