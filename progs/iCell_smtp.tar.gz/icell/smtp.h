//
// Created by aximcore on 2015.08.19..
//

#ifndef ICELL_SMTP_H
#define ICELL_SMTP_H

#include <boost/asio.hpp>
#include <boost/lexical_cast.hpp>
#include <stdlib.h>
#include <queue>
#include <iostream>
#include <csignal>
#include <thread>

using boost::asio::ip::tcp;

class Message {
    std::string from, to, data;
public:
    Message();
    Message(std::string, std::string, std::string);

    bool isCorrect();
    std::string getFrom();
    std::string getTo();
    std::string getData();
};

class Send {
    boost::asio::io_service io_service;
    tcp::socket socket;
    tcp::resolver resolver;
    tcp::resolver::iterator endpoint_iterator;
    boost::system::error_code ignored_error;
    boost::asio::streambuf request;
    boost::asio::streambuf response;
public:
    Send(std::string host = "localhost", std::string port = "25");
    void messageSend(Message);
};


#endif //ICELL_SMTP_H
