//
// Created by aximcore on 2015.08.24..
//

#include "manager.h"

Manager::Manager() {
    Manager::messages = json.loadFile();
    t.join();
}

Manager::~Manager() {
    if(!Manager::messages.empty()) {
        std::cout << "Fájlba való mentés." << std::endl;
        json.saveFile(Manager::messages);
    }
    std::cout << "Program bezárása!" << std::endl;
}

Manager* Manager::getInstance() {
    if(!instance) {
        instance = new Manager();
        return instance;
    } else {
        return instance;
    }
}

std::atomic<bool> done(false);
std::thread Manager::t(Manager::sendToSMTP);

void Manager::startDeliver() {
    if(done) {
        Manager::t = std::thread(Manager::sendToSMTP);
        t.join();
    }
}

void Manager::sendToSMTP() {
    done = false;

    while(!messages.empty()) {
        smtp.messageSend(messages.front());
        messages.pop();
    }

    done = true;
    t.detach();
}

void Manager::saveRequest(boost::asio::streambuf* m) {
    std::queue<Message> temp = json.parseRequest(m);

    while(!temp.empty()) {
        messages.push(temp.front());
        temp.pop();
    }

    Manager::startDeliver();
}

void Manager::signalHandler(int) {
    delete Manager::instance;
    exit(0);
}

Send Manager::smtp;
JSON Manager::json;
std::queue<Message> Manager::messages;
Manager* Manager::instance = 0;