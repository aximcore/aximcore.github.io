//
// Created by aximcore on 2015.08.19..
//

#include "smtp.h"

Message::Message(std::string from, std::string to, std::string data) : from(from), to(to), data(data) {}

Message::Message() {}

bool Message::isCorrect() {
    if ( Message::to.empty() || Message::from.empty() ) {
        return false;
    }
    return true;
}

std::string Message::getFrom() { return this->from; }

std::string Message::getTo() { return  this->to; }

std::string Message::getData() { return this->data; }


Send::Send(std::string host, std::string port) : socket(io_service), resolver(io_service) {
    tcp::resolver::query query(host, port);
    endpoint_iterator = resolver.resolve(query);
    boost::asio::connect(socket, endpoint_iterator, ignored_error);
}

void Send::messageSend(Message m) {
    if (!m.isCorrect()){ return; }

    std::string res;
    std::istream response_stream(&response);
    std::ostream request_stream(&request);

    for(int i = 0; i < 4; i++){

        switch(i){
            case 0:
                request_stream << "MAIL FROM: " << m.getFrom() << "\n";
                break;
            case 1:
                request_stream << "RCPT TO: " << m.getTo() << "\n";
                break;
            case 2:
                request_stream << "DATA\n";
                break;
            case 3:
                request_stream << m.getData() << "\n";
                request_stream << ".\r\n";
                break;
        }

        boost::asio::write(socket, request);
        boost::asio::read_until(socket, response, "\r\n");
        std::getline(response_stream, res);
        //std::cout << res << std::endl;
    }

}