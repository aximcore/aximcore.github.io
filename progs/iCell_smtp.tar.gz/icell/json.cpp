//
// Created by aximcore on 2015.08.21..
//

#include "json.h"

#include <boost/foreach.hpp>

JSON::JSON() : fileName("save.json") {}

void JSON::saveFile(std::queue<Message> messages) {
    while(!messages.empty()){
        ptree temp;
        temp.put("From", messages.front().getFrom());
        temp.put("To",messages.front().getTo());
        temp.put("Data", messages.front().getData());
        message.push_back(temp);
        messages.pop();
    }

    for(auto pt : message) {
        messages_.push_back(std::make_pair("", pt));
    }

    root.add_child("messages",messages_);

    file.open(fileName, std::ios::out | std::ios::trunc);
    if(file.is_open()) {
        write_json(file, root);
        file.close();
    } else {
        std::cerr << "Nem tudtam fájlt létrehozni!" << std::endl;
    }
}

std::queue<Message> JSON::loadFile() {
    std::cout << "Fájl beolvasása." << std::endl;
    file.open(fileName, std::ios::in);
    std::queue<Message> temp;

    if(!file.is_open()) {
        return temp;
    }

    read_json(file, root);
    file.close();
    try {
        BOOST_FOREACH(ptree::value_type &v, root.get_child("messages")) {
                        temp.push(Message(v.second.get("From",""),
                                          v.second.get("To",""),
                                          v.second.get("Data","")));
                    }
    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }

    if (remove(fileName.c_str()) != 0) {
        std::cerr << "Nem sikerült törölni!" << std::endl;
    }

    std::cout << "Fájl beolvasás kész!" << std::endl;

    return temp;
}

std::queue<Message> JSON::parseRequest(boost::asio::streambuf* m) {
    std::queue<Message> temp;
    ptree pt;
    std::istream input(m);
    read_json(input, pt);

    try {
        BOOST_FOREACH(ptree::value_type &v, pt.get_child("messages")) {
                        temp.push(Message(v.second.get("From",""),
                                          v.second.get("To",""),
                                          v.second.get("Data","")));
                    }
    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }

    return temp;
}
