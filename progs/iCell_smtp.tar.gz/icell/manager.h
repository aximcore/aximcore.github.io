//
// Created by aximcore on 2015.08.24..
//

#ifndef ICELL_MANAGER_H
#define ICELL_MANAGER_H

#include "json.h"
#include "smtp.h"

class Manager {
    Manager();
    static Manager *instance;
    Manager(Manager const&)         = delete;
    void operator=(Manager const&)  = delete;

    static JSON json;
    static std::thread t;
public:
    ~Manager();
    static Manager *getInstance();

    static void signalHandler(int);

    static Send smtp;
    static std::queue<Message> messages;
    static void startDeliver();
    static void sendToSMTP();
    static void saveRequest(boost::asio::streambuf*);
};

#endif //ICELL_MANAGER_H
